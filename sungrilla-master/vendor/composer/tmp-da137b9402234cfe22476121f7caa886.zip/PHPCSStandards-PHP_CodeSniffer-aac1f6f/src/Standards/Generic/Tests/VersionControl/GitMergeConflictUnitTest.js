
result = x?y:z;
result = x ? y : z;

<<<<<<< HEAD
if (something === true
=======
if (something === false
>>>>>>> develop
    ^ somethingElse === true
) {
<<<<<<< HEAD
    return true;
=======
    return false;
>>>>>>> develop
}

y = 1
  + 2
  - 3;

/*
<<<<<<< HEAD
 * @var string $bar
 */
if (something === true

/**
=======
 * @var string $foo
>>>>>>> master
 */
