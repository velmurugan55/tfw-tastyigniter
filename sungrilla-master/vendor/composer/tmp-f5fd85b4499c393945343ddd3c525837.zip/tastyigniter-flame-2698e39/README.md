# TastyIgniter Flame :fire: 
This repository contains the core library of TastyIgniter. If you want to setup a ordering platform using TastyIgniter, checkout the main TastyIgniter repository.
