<?php

namespace Igniter\Flame\Pagic\Extension;

class CoreExtension extends AbstractExtension
{
    public function getDirectives()
    {
        return [];
    }
}
