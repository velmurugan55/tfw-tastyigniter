<?php

namespace Igniter\Flame\Pagic\Extension;

abstract class AbstractExtension
{
    public function getDirectives()
    {
        return [];
    }
}
