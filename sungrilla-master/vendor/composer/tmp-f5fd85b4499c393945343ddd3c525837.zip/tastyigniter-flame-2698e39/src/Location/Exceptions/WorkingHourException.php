<?php

namespace Igniter\Flame\Location\Exceptions;

class WorkingHourException extends \Exception
{
}
