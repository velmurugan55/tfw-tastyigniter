<?php

/*
 * This file is part of the Assetic package, an OpenSky project.
 *
 * (c) 2010-2014 OpenSky Project Inc
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Igniter\Flame\Assetic\Exception;

/**
 * Marker.
 *
 * @author Johannes M. Schmitt <schmittjoh@gmail.com>
 */
interface Exception
{
}
