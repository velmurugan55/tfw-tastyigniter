<?php

namespace Igniter\Flame\Exception;

class ApplicationException extends BaseException
{
}
