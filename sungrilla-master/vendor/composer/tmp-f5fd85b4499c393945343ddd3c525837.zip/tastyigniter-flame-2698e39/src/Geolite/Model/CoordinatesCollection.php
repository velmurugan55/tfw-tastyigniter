<?php

namespace Igniter\Flame\Geolite\Model;

use Illuminate\Support\Collection;

class CoordinatesCollection extends Collection
{
}
