<?php

namespace Igniter\Flame\Geolite\Exception;

class GeoliteException extends \Exception
{
}
