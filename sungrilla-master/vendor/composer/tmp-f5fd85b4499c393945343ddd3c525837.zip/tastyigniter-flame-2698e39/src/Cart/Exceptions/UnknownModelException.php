<?php

namespace Igniter\Flame\Cart\Exceptions;

use RuntimeException;

class UnknownModelException extends RuntimeException
{
}
