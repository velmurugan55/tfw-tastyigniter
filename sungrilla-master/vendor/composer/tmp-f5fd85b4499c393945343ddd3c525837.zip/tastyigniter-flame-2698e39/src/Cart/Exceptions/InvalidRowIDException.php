<?php

namespace Igniter\Flame\Cart\Exceptions;

use RuntimeException;

class InvalidRowIDException extends RuntimeException
{
}
