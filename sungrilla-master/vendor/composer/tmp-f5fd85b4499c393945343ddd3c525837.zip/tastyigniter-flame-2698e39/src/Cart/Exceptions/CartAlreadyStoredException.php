<?php

namespace Igniter\Flame\Cart\Exceptions;

use RuntimeException;

class CartAlreadyStoredException extends RuntimeException
{
}
