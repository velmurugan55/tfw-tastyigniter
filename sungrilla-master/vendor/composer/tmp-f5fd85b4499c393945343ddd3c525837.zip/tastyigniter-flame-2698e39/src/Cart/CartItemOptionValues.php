<?php

namespace Igniter\Flame\Cart;

use Illuminate\Support\Collection;

class CartItemOptionValues extends Collection
{
}
