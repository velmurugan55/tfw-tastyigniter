<?php

namespace Igniter\Flame\Foundation\Providers;

use Illuminate\Foundation\Support\Providers\EventServiceProvider as BaseEventServiceProvider;

class EventServiceProvider extends BaseEventServiceProvider
{
    /**
     * The event listener mappings for the application.
     *
     * @var array
     */
    protected $listen = [
        //        'App\Events\Event' => [
        //            'App\Listeners\EventListener',
        //        ],
    ];
}
