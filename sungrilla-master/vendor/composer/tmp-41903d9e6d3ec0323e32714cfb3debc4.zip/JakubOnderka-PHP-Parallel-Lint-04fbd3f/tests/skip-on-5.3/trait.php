<?php // lint >= 5.4

trait ExampleTrait
{

}
