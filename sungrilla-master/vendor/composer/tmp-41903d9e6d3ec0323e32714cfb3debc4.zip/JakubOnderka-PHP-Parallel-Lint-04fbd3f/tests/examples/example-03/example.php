<?php

$myInteger = 1;
echo $;
