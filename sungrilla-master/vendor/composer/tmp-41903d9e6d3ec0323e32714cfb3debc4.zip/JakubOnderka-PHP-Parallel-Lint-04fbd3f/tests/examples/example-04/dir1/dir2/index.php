<?php
$foo ='bar'
echo $foo;
